# CDR Phase III.2 — Audit Bundle

- **Bundle version:** `phase3_2_audit_bundle_v1`
- **Created at:** `2026-06-01 23:09:08`
- **Project:** `Phase3.2-Regime-Lag-Conditional-EEG-RNG`
- **Phase:** `Phase III.2`
- **Phase title:** `Regime-Aware, Lagged and Conditional EEG-RNG Validation`
- **Code/config version:** `v1.0`

## Final status

- **Metrics status:** `exploratory_lead_with_saturation_warning`
- **Diagnostics headline:** `Phase III.2 produced exploratory leads with ε saturation warning.`
- **Diagnostics status:** `exploratory_lead_with_saturation_warning`

**Interpretation:**

> Exploratory conditional lift appeared, but epsilon saturation diagnostics raised a warning. The result cannot be interpreted as evidence without additional diagnostics.

**Diagnostic recommendation:**

> Treat Phase III.2 as an exploratory lead only. Controls passed, but F7/F8 failed and F12 raised an ε saturation warning. Do not claim EEG-RNG coupling. The appropriate next step is to document the lead, preserve the null/guardrail interpretation, and only activate III.2D/III.2E as exploratory extensions or future protocol work.

## Gate summary

- **Passed gates:** `['F2', 'F3', 'F6', 'F9', 'F10', 'F11']`
- **Failed gates:** `['F7', 'F8']`
- **Warning gates:** `['F12']`
- **Not evaluated gates:** `['F1', 'F5']`

## Controls

- **Controls passed:** `True`
- **Failed control types:** `[]`
- **Number of control types:** `6`

## Conditional results

- **Valid pair rows:** `84`
- **Positive lift rows:** `6`
- **Strong candidate rows:** `0`
- **Best by lift:** `{'regime': 'stable_sleep', 'lag_epochs': 1, 'family': 'RNG_next', 'baseline_model': 'C2_RNG_next_given_RNG', 'augmented_model': 'C3_RNG_next_given_RNG_EEG', 'conditional_lift': 0.8, 'augmented_eps_test': 0.8, 'fraction_positive_lift': 0.5, 'll_improvement': -2.51574933659208, 'bic_improvement': -125.17209340333238, 'primary': False}`

## Bundle contents

- **Included files:** `47`
- **Missing expected files:** `2`
- **Raw data files inventoried:** `54`

Raw EDF/RNG files are not copied into the bundle by default. Their metadata and hashes are recorded in the manifest when available.
